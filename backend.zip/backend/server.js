const express = require("express");
const cors = require("cors");
const { createServer, startServer, stopServer } = require("./mcManager");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/create", async (req, res) => {
  const { name, version } = req.body;
  await createServer(name, version);
  res.json({ ok: true });
});

app.post("/start", (req, res) => {
  const { name, ram } = req.body;
  startServer(name, ram);
  res.json({ started: true });
});

app.post("/stop", (req, res) => {
  const { name } = req.body;
  stopServer(name);
  res.json({ stopped: true });
});

app.listen(3000, () => console.log("✅ Backend läuft auf http://localhost:3000"));

const fs = require("fs");
const { spawn } = require("child_process");
const path = require("path");

const serversDir = path.join(__dirname, "servers");
if (!fs.existsSync(serversDir)) fs.mkdirSync(serversDir);

let processes = {};

function createServer(name, version="1.20.1") {
  return new Promise((resolve, reject) => {
    const serverPath = path.join(serversDir, name);
    if (!fs.existsSync(serverPath)) fs.mkdirSync(serverPath);

    const jarPath = path.join(serverPath, "server.jar");

    if (!fs.existsSync(jarPath)) {
      // PaperMC herunterladen
      const url = `https://api.papermc.io/v2/projects/paper/versions/${version}/builds/1/downloads/paper-${version}-1.jar`;
      const wget = spawn("curl", ["-L", url, "-o", jarPath]);

      wget.on("close", () => {
        fs.writeFileSync(path.join(serverPath, "eula.txt"), "eula=true");
        resolve();
      });
    } else {
      resolve();
    }
  });
}

function startServer(name, ram="1024") {
  const serverPath = path.join(serversDir, name);
  if (!fs.existsSync(serverPath)) return;

  const jarPath = path.join(serverPath, "server.jar");
  if (!fs.existsSync(jarPath)) return;

  // RAM in MB umrechnen
  const ramValue = parseInt(ram) * 1024;

  const proc = spawn("java", [`-Xmx${ramValue}M`, "-jar", "server.jar", "nogui"], {
    cwd: serverPath
  });

  processes[name] = proc;

  proc.stdout.on("data", d => console.log(`[${name}] ` + d.toString()));
  proc.stderr.on("data", d => console.error(`[${name}] ` + d.toString()));
}

function stopServer(name) {
  const proc = processes[name];
  if (proc) proc.kill();
}

module.exports = { createServer, startServer, stopServer };
